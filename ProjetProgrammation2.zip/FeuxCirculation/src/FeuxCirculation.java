import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Component;
import java.awt.Canvas;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JRadioButton;

public class FeuxCirculation {

	private JFrame frm_Principal;
	private JLabel lblNewLabel;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FeuxCirculation window = new FeuxCirculation();
					window.frm_Principal.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FeuxCirculation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frm_Principal = new JFrame();
		frm_Principal.setTitle("Feux Circulation");
		frm_Principal.setBounds(100, 100, 1004, 618);
		frm_Principal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frm_Principal.setJMenuBar(menuBar);
		
		JMenu mnFichier = new JMenu("Fichier");
		menuBar.add(mnFichier);
		
		JMenuItem mntmQuitter = new JMenuItem("Quitter");
		mnFichier.add(mntmQuitter);
		
		JMenu mnApropos = new JMenu("Aide");
		menuBar.add(mnApropos);
		
		JMenuItem mntmAPropos = new JMenuItem("A propos");
		mnApropos.add(mntmAPropos);
		frm_Principal.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel.setBounds(10, 11, 716, 535);
		frm_Principal.getContentPane().add(panel);
		panel.setLayout(null);
		
		Canvas canvas = new Canvas();
		canvas.setBounds(10, 10, 696, 515);
		panel.add(canvas);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_1.setBounds(729, 11, 245, 535);
		frm_Principal.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setIcon(new ImageIcon("F:\\ECLI\\FeuxCirculation\\img\\play.jpg"));
		btnNewButton.setBounds(10, 11, 40, 37);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setIcon(new ImageIcon("F:\\ECLI\\FeuxCirculation\\img\\stop.jpg"));
		btnNewButton_1.setBounds(60, 11, 40, 37);
		panel_1.add(btnNewButton_1);
		
		JSlider slider = new JSlider();
		slider.setToolTipText("Vitesse des voitures");
		slider.setBounds(10, 81, 200, 26);
		panel_1.add(slider);
		
		JLabel lblVitesse = new JLabel("Vitesse des voitures");
		lblVitesse.setToolTipText("Vitesse des voitures");
		lblVitesse.setBounds(46, 120, 164, 14);
		panel_1.add(lblVitesse);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("En \u00E9quilibre");
		rdbtnNewRadioButton.setBounds(46, 177, 123, 25);
		panel_1.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("A risque ");
		rdbtnNewRadioButton_1.setBounds(46, 207, 123, 25);
		panel_1.add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Congestionn\u00E9");
		rdbtnNewRadioButton_2.setBounds(46, 232, 123, 25);
		panel_1.add(rdbtnNewRadioButton_2);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		lblNewLabel.setBounds(42, 167, 142, 105);
		panel_1.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(33, 356, 40, 22);
		panel_1.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("OK");
		btnNewButton_2.setBounds(85, 355, 97, 25);
		panel_1.add(btnNewButton_2);
		
		JLabel lblNewLabel_1 = new JLabel("Nombre voitures dans le tron\u00E7on ");
		lblNewLabel_1.setBounds(33, 329, 200, 16);
		panel_1.add(lblNewLabel_1);
	}
}
