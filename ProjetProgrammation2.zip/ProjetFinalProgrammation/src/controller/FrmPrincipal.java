package controller;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import view.GUI_CarteCentrale;
import view.GUI_FeuxSignalisation;
import view.GUI_Parametres;
import view.GUI_Trajet;
import view.GUI_Troncon;

/*
 * Cette classe nous permet de definir la fenetre principale de notre animation.
 * */
public class FrmPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;

	/*
	 * On definit la resolution minimale de l'ecran pour pouvoir executer notre
	 * application
	 */
	private final int RESOLUTION_ECRAN_LARGEUR_MIN = 1400;
	private final int RESOLUTION_ECRAN_HAUTEUR_MIN = 800;

	public FrmPrincipal() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		if (screenSize.getWidth() < RESOLUTION_ECRAN_LARGEUR_MIN
				&& screenSize.getHeight() < RESOLUTION_ECRAN_HAUTEUR_MIN) {
			int choix = JOptionPane.showConfirmDialog(null,
					"La r�solution de votre �cran est inferieure � la r�solution recommand�e. La qualit� de l�affichage sera d�grad�e.\r\n"
							+ "Voulez-vous continuer ?\r\n" + "",
							"Probl�me r�solution �cran", JOptionPane.YES_NO_OPTION);
			if (choix == JOptionPane.YES_OPTION) {

			} else {
				System.exit(0);
			}
		}

		this.setBounds(0, 0, 1400, 800);
		this.setResizable(false);
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("img/icon.jpg"));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBounds(10, 10, this.getSize().width, this.getSize().height);
		this.setContentPane(contentPane);
		contentPane.setLayout(null);
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					// On instancie la fenetre principale de notre application
					FrmPrincipal frame = new FrmPrincipal();

					// Image du fond d'ecran
					BufferedImage img = null;
					try {
						File f = new File("img/bg.PNG");
						img = ImageIO.read(f);
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}

					// On instancie le panneau qui contient l'animation
					GUI_CarteCentrale pnlCentral = new GUI_CarteCentrale((JPanel) frame.getContentPane(), img);

					// On instancie les differents troncons de route
					GUI_Troncon lesTroncons = new GUI_Troncon(pnlCentral);

					// On instancie les differents trajets possibles. Un trajet etant une suite de
					// troncons
					GUI_Trajet lesTrajets = new GUI_Trajet(lesTroncons.getListeTroncon(),
							lesTroncons.getListePositionsParTroncon());

					// On instancie le feux et les autres signalisations (Panneau, timer, etc.)
					GUI_FeuxSignalisation feuxSignalisation = new GUI_FeuxSignalisation(pnlCentral);

					// On instancie le panneau qui contient les composants de controle de
					// l'application
					new GUI_Parametres((JPanel) frame.getContentPane(), pnlCentral,
							lesTrajets.getListePositionsTrajet(), lesTroncons, feuxSignalisation);

					frame.setVisible(true);
				} catch (Exception e) {
					e.getMessage();
				}
			}
		});
	}
}
