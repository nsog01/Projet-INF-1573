package model;

/*Cette classe definit le feu de signalisation*/
public class FeuxSignalisation {
	private int couleur;
	private int duree;

	public static int getCouleurVerte() {
		return 1;
	}

	public static int getCouleurJaune() {
		return 2;
	}

	public static int getCouleurRouge() {
		return 3;
	}

	public int getCouleur() {
		return couleur;
	}

	public int getDuree() {
		return duree;
	}

	public void setCouleur(int couleur) {
		this.couleur = couleur;
	}

	public void setDuree(int duree) {
		this.duree = duree;
	}

	public FeuxSignalisation(int couleur, int duree) {
		this.couleur = couleur;
		this.duree = duree;
	}

}
