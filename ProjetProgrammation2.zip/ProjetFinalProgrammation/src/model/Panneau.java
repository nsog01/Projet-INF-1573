package model;

/*Cette classe definit le panneau pour afficher les messages*/
public class Panneau {
	private String message;

	public Panneau() {
		message = null;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
