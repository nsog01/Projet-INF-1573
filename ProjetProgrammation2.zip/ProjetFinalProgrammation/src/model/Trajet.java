package model;

import java.util.ArrayList;

/*Un trajet est une suite de troncons*/
public class Trajet {

	private ArrayList<Troncon> trajet;

	public Trajet() {
		trajet = new ArrayList<Troncon>();
	}

	public ArrayList<Troncon> getListeTroncons() {
		return trajet;
	}

	public void ajouterTroncon(Troncon tr) {
		trajet.add(tr);
	}

	public int nombreTronconsDuTrajet() {
		return trajet.size();
	}
}
