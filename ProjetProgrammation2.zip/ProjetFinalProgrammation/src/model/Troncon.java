package model;

import java.awt.Point;
import java.util.ArrayList;

/*
 * Cette classe permet de definir les differents troncons. Nous utiliserons plutard la notion de 
 * troncon pour definir la notion de TRAJET, un TRAJET etant une suite de troncons. Et un troncon 
 * definit l'ensemble des positions (repere dans l'espace) que peut occuper une voiture sur ledit troncon.
 */
public class Troncon {
	private final int capaciteMax;
	private Point debutTroncon;
	private Point finTroncon;
	private int numeroTroncon;
	private ArrayList<Voiture> fileVoiture;

	public int getCapaciteMax() {
		return capaciteMax;
	}

	public int getNumeroTroncon() {
		return numeroTroncon;
	}

	public Point getDebutTroncon() {
		return debutTroncon;
	}

	public Point getFinTroncon() {
		return finTroncon;
	}

	public boolean estCongestionne() {
		return fileVoiture.size() == capaciteMax;
	}

	public int getTailleFileVoiture() {
		return this.fileVoiture.size();
	}

	public Troncon(int numeroTroncon, Point debutTroncon, Point finTroncon, int capaciteMax) {
		this.numeroTroncon = numeroTroncon;
		this.debutTroncon = debutTroncon;
		this.finTroncon = finTroncon;
		this.capaciteMax = capaciteMax;
		fileVoiture = new ArrayList<Voiture>();
	}

	public void ajouterVoiture(Voiture voiture) {
		if (fileVoiture.size() < capaciteMax) {
			fileVoiture.add(voiture);
		}

	}

	public boolean fileEstVide() {
		return fileVoiture.size() == 0;
	}
}
