package model;

import java.awt.Point;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import view.GUI_Point;

/*Cette classe definit les voitures*/
public class Voiture {
	private int couleur;
	private Point position;
	private ArrayList<GUI_Point> trajet;
	private BufferedImage logo;

	public BufferedImage getLogo() {
		return logo;
	}

	public void setLogo(BufferedImage logo) {
		this.logo = logo;
	}

	public Point getPosition() {
		return position;
	}

	public int getCouleur() {
		return couleur;
	}

	public ArrayList<GUI_Point> getTrajet() {
		return trajet;
	}

	public void setPosition(Point position) {
		this.position = position;
	}

	public Voiture(int couleur, int x, int y, BufferedImage logo, ArrayList<GUI_Point> trajet) {
		this.position = new Point();
		this.couleur = couleur;
		this.position.setLocation(x, y);
		this.trajet = trajet;
		this.logo = logo;
	}
}
