package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Rectangle;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/*
 * Cette classe nous permet de definir le panneau central qui va contenir notre animation.
 * */
public class GUI_CarteCentrale extends JPanel {
	private static final long serialVersionUID = 1L;
	public static final int SCALED = 0;
	private Paint painter;
	private Image image;

	public GUI_CarteCentrale(JPanel unPanel, Image image) {
		this(image);
		this.setBorder(new LineBorder(new Color(0, 0, 0)));
		this.setBounds(unPanel.getX(), unPanel.getY(), unPanel.getSize().width * 4 / 5, unPanel.getSize().height);
		unPanel.add(this);
		this.setLayout(null);
	}

	/*
	 * Definit image comme image de fond
	 */
	public GUI_CarteCentrale(Image image) {
		setImage(image);
		setLayout(new BorderLayout());
	}

	public void setImage(Image image) {
		this.image = image;
		repaint();
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		if (painter != null) {
			Dimension d = getSize();
			Graphics2D g2 = (Graphics2D) g;
			g2.setPaint(painter);
			g2.fill(new Rectangle(0, 0, d.width, d.height));
		}

		dessine(g);
	}

	private void dessine(Graphics g) {
		Dimension d = getSize();
		g.drawImage(image, 0, 0, d.width, d.height, null);
	}
}