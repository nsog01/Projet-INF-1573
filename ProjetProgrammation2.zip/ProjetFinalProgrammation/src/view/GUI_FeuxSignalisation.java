package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import model.FeuxSignalisation;

/*
 * Cette classe nous permet de gerer l'affichage du feux de signalisation et 
 * le changement de message sur le panneau.
 * */
public class GUI_FeuxSignalisation {

	private JButton btnFeuxSignal;
	private JLabel lblPanneau;
	private JLabel lblCompteur;
	private FeuxSignalisation feu;

	public FeuxSignalisation getFeu() {
		return feu;
	}

	public GUI_FeuxSignalisation(JPanel unPanel) {
		feu = new FeuxSignalisation(FeuxSignalisation.getCouleurVerte(), 20);
		this.btnFeuxSignal = new JButton();
		this.lblPanneau = new JLabel();
		this.lblCompteur = new JLabel();

		BufferedImage img = null;
		try {
			File f = new File("img/gl.png");
			img = ImageIO.read(f);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		/* On definit le bouton qui affiche le feux */
		btnFeuxSignal.setBounds(468, 440, 16, 45);
		btnFeuxSignal.setIcon(new ImageIcon(img));
		btnFeuxSignal.setOpaque(false);
		btnFeuxSignal.setContentAreaFilled(false);
		btnFeuxSignal.setBorderPainted(false);

		/* On definit le panneau */
		lblPanneau.setFont(new Font("OCR A Extended", Font.PLAIN, 17));
		lblPanneau.setBounds(300, 284, 200, 40);
		lblPanneau.setBackground(Color.BLACK);
		lblPanneau.setHorizontalAlignment(SwingConstants.CENTER);
		lblPanneau.setVerticalAlignment(SwingConstants.CENTER);
		lblPanneau.setOpaque(true);
		lblPanneau.setBorder(BorderFactory.createLineBorder(Color.black));

		/* On definit le Timer du feux de signalisation */
		lblCompteur.setText("" + feu.getDuree());
		lblCompteur.setFont(new Font("OCR A Extended", Font.PLAIN, 37));
		lblCompteur.setBounds(456, 460, 103, 88);
		unPanel.add(lblCompteur);
		unPanel.add(btnFeuxSignal);
		unPanel.add(lblPanneau);
	}

	/* Cette methode permet de faire le decompte Timer */
	public void changerCompteur() {
		int val;
		if (lblCompteur.getText().equals("0")) {
			changerFeux();
			lblCompteur.setText(feu.getDuree() + "");

		} else {
			val = Integer.parseInt(lblCompteur.getText()) - 1;
			lblCompteur.setText("" + val);
		}
	}

	/*
	 * Cette methode permet de changer le message qui s'affiche sur le panneau en
	 * fonction de l'etat du trafic
	 */
	public void changerMesssagePanneau(boolean rondPointPresquePlein, int nombreVoitureActives,
			int nombreVoitureTronconSortie) {
		if (nombreVoitureActives < 44) {
			lblPanneau.setText("Trafic �quilibr�");
			lblPanneau.setForeground(Color.GREEN);
		} else {
			if (nombreVoitureTronconSortie > 5) {
				lblPanneau.setText("Risque Congestion");
				lblPanneau.setForeground(Color.ORANGE);
				if (rondPointPresquePlein) {
					lblPanneau.setText("Trafic congestionn�");
					lblPanneau.setForeground(Color.RED);
				} else {
					lblPanneau.setText("Risque Congestion");
					lblPanneau.setForeground(Color.ORANGE);
				}

			} else {
				lblPanneau.setText("Trafic �quilibr�");
				lblPanneau.setForeground(Color.GREEN);
			}

		}
	}

	/* Cette methode permet de changer le feux de signalisation */
	public void changerFeux() {
		BufferedImage imgVerte = null;
		try {
			File f = new File("img/gl.png");
			imgVerte = ImageIO.read(f);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		BufferedImage imgJaune = null;
		try {
			File f = new File("img/yl.png");
			imgJaune = ImageIO.read(f);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		BufferedImage imgRouge = null;
		try {
			File f = new File("img/rl.png");
			imgRouge = ImageIO.read(f);
		} catch (Exception ex) {
			System.out.println(ex);
		}

		switch (feu.getCouleur()) {
		case 1:
			feu.setDuree(3);
			feu.setCouleur(FeuxSignalisation.getCouleurJaune());
			btnFeuxSignal.setIcon(new ImageIcon(imgJaune));
			break;

		case 2:
			feu.setDuree(25);
			feu.setCouleur(FeuxSignalisation.getCouleurRouge());
			btnFeuxSignal.setIcon(new ImageIcon(imgRouge));
			break;

		case 3:
			feu.setDuree(20);
			feu.setCouleur(FeuxSignalisation.getCouleurVerte());
			btnFeuxSignal.setIcon(new ImageIcon(imgVerte));
			break;

		default:
			;
		}

	}

}
