package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;

/*
 * Cette classe permet de definir le panneau qui contient les composants de parametrage de l'application,
 * comme la vitesse de l'animation, le nombre de vehicules dans le rond-point ou dans le troncon, etc.
 * */
public class GUI_Parametres extends JPanel {

	/*
	 * Parametres servant a definir la vitesse d'animation
	 */
	private final int VITESSE_ANIMATION_MIN = 0;
	private final int VITESSE_ANIMATION_MAX = 1900;
	private final int VITESSE_ANIMATION_INITIALE = 1000;

	private Timer timer1;
	private Timer timer2;

	/* Bouton pour lancer une animation */
	private JButton btnPlay;

	/* Le JComboBox pour definir le nombre total de voitures pour l'animation */
	private JComboBox<Integer> comboNbreVoituresTotal;
	private JLabel lblNbreTotalVoiture;

	/* Slider pour modifier la vitesse d'une simulation */
	private JLabel lblVitesseAnimation;
	private JSlider slider_VitesseAnimation;

	/* Le JComboBox pour definir le nombre de voiture dans le rond-point */
	private JLabel lblNbreVoituresRP;
	private JComboBox<Integer> comboNbreVoitureRP;

	/* Le JComboBox pour le nombre de voiture dans le troncon */
	private JLabel lblNbreVoitureTroncon;
	private JComboBox<Integer> comboNbreVoituresTroncon;

	/* Le bouton pour Quitter l'application */
	private JButton btnQuitter;

	private static final long serialVersionUID = 1L;

	public int getVitesseAnimation() {
		return slider_VitesseAnimation.getValue();
	}

	public int getNombreVoitureRondPoint() {
		return (int) comboNbreVoitureRP.getSelectedItem();
	}

	public int getNombreVoitureTroncon() {
		return (int) comboNbreVoituresTroncon.getSelectedItem();
	}

	public int getNombreVoitureTotal() {
		return (int) comboNbreVoituresTotal.getSelectedItem();
	}

	public GUI_Parametres(JPanel unPanel, JPanel pnlCentral, ArrayList<ArrayList<GUI_Point>> listePositionsTrajet,
			GUI_Troncon troncon, GUI_FeuxSignalisation feuxSignalisation) {
		this.setBorder(new LineBorder(new Color(0, 0, 0)));
		this.setBounds(unPanel.getSize().width * 4 / 5, unPanel.getY(), unPanel.getSize().width * 1 / 5,
				unPanel.getSize().height);
		unPanel.add(this);
		this.setLayout(null);

		/* On definit le bouton pour lancer une animation */
		btnPlay = new JButton("Lancer la simulation");
		btnPlay.setBounds(unPanel.getX() + 20, unPanel.getY(), 160, 30);
		btnPlay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (btnPlay.getText().equals("Lancer la simulation")) {
					btnPlay.setText("Arr�ter la simulation");
					start(pnlCentral, listePositionsTrajet, troncon.getSprite(), feuxSignalisation);
					slider_VitesseAnimation.setEnabled(false);
					comboNbreVoituresTotal.setEnabled(false);
					comboNbreVoitureRP.setEnabled(false);
					comboNbreVoituresTroncon.setEnabled(false);

				} else {
					btnPlay.setText("Lancer la simulation");
					slider_VitesseAnimation.setEnabled(true);
					comboNbreVoituresTotal.setEnabled(true);
					comboNbreVoitureRP.setEnabled(true);
					comboNbreVoituresTroncon.setEnabled(true);
					arreter(troncon);

				}
			}
		});
		this.add(btnPlay);

		/* On definit le slider pour modifier la vitesse d'une animation */
		lblVitesseAnimation = new JLabel("Vitesse animation");
		lblVitesseAnimation.setBounds(unPanel.getX() + 20, 110, 209, 14);
		this.add(lblVitesseAnimation);

		slider_VitesseAnimation = new JSlider(JSlider.HORIZONTAL, VITESSE_ANIMATION_MIN, VITESSE_ANIMATION_MAX,
				VITESSE_ANIMATION_INITIALE);
		slider_VitesseAnimation.setBounds(unPanel.getX() + 20, 135, 175, 26);
		this.add(slider_VitesseAnimation);

		/* On definit le JComboBox pour le nombre de voiture dans le rond-point */
		lblNbreVoituresRP = new JLabel("Rond-point: Nombre de voitures.");
		lblNbreVoituresRP.setBounds(unPanel.getX() + 20, 195, 219, 14);
		this.add(lblNbreVoituresRP);

		comboNbreVoitureRP = new JComboBox<Integer>();
		comboNbreVoitureRP.addItem(4);
		comboNbreVoitureRP.addItem(5);
		comboNbreVoitureRP.addItem(6);
		comboNbreVoitureRP.addItem(7);
		comboNbreVoitureRP.setSelectedIndex(3);
		comboNbreVoitureRP.setBounds(unPanel.getX() + 20, 210, 175, 22);
		this.add(comboNbreVoitureRP);

		/* On definit le JComboBox pour le nombre de voiture dans le troncon */
		lblNbreVoitureTroncon = new JLabel("Tron�on: Nombre de voitures");
		lblNbreVoitureTroncon.setBounds(unPanel.getX() + 20, 255, 219, 14);
		this.add(lblNbreVoitureTroncon);

		comboNbreVoituresTroncon = new JComboBox<Integer>();
		comboNbreVoituresTroncon.addItem(5);
		comboNbreVoituresTroncon.addItem(6);
		comboNbreVoituresTroncon.addItem(7);
		comboNbreVoituresTroncon.addItem(8);
		comboNbreVoituresTroncon.addItem(9);
		comboNbreVoituresTroncon.setBounds(unPanel.getX() + 20, 270, 175, 22);
		comboNbreVoituresTroncon.setSelectedIndex(4);
		this.add(comboNbreVoituresTroncon);

		/* On definit le JComboBox pour le nombre total de voiture pour l'animation */
		lblNbreTotalVoiture = new JLabel("Simulation: Nombre total voitures");
		lblNbreTotalVoiture.setBounds(unPanel.getX() + 20, 315, 219, 14);
		this.add(lblNbreTotalVoiture);

		comboNbreVoituresTotal = new JComboBox<Integer>();
		comboNbreVoituresTotal.addItem(25);
		comboNbreVoituresTotal.addItem(50);
		comboNbreVoituresTotal.addItem(75);
		comboNbreVoituresTotal.addItem(100);
		comboNbreVoituresTotal.addItem(150);
		comboNbreVoituresTotal.addItem(200);
		comboNbreVoituresTotal.setSelectedIndex(4);
		comboNbreVoituresTotal.setBounds(unPanel.getX() + 20, 330, 175, 22);
		this.add(comboNbreVoituresTotal);

		/* On definit le bouton pour Quitter l'application */
		btnQuitter = new JButton("Quitter");
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnQuitter.setBounds(unPanel.getX() + 20, 600, 160, 30);
		this.add(btnQuitter);
	}

	public void start(JPanel pnlCentral, ArrayList<ArrayList<GUI_Point>> listePositionsTrajet,
			ArrayList<JButton> sprite, GUI_FeuxSignalisation feuxSignalisation) {
		// On instancie gui_Voiture pour generer les voitures (selon le nombre total
		// defini par l'utilisateur)
		GUI_Simulation simulation = new GUI_Simulation(listePositionsTrajet, getNombreVoitureTotal());

		timer1 = new Timer();
		timer2 = new Timer();

		TimerTask task1 = new TimerTask() {
			@Override
			public void run() {
				simulation.initialiser(pnlCentral, sprite, feuxSignalisation.getFeu().getCouleur(),
						getNombreVoitureRondPoint());
			};
		};

		TimerTask task2 = new TimerTask() {
			@Override
			public void run() {
				feuxSignalisation.changerCompteur();
				feuxSignalisation.changerMesssagePanneau(
						simulation.rondPointEstCongestionne(sprite, getNombreVoitureRondPoint()),
						simulation.nombreVoituresActives(sprite), simulation.nombreVoitureSurTronconSortie());
			};
		};

		// On simule le trafic
		timer1.schedule(task1, 1000, 2000 - getVitesseAnimation());

		// On simule le changement de feux de signalisation et les changements de
		// messages du panneau.
		timer2.schedule(task2, 1000, 1000);

	}

	public void arreter(GUI_Troncon troncon) {
		timer1.cancel();
		timer1.purge();
		timer2.cancel();
		timer2.purge();
		troncon.reinitialiseSprite();
	}

}
