package view;

import java.awt.Point;

/*Cette classe nous permet de definir une position que peut occuper une voiture sur un troncon quelconque */
public class GUI_Point extends Point {
	private static final long serialVersionUID = 1L;
	private int numeroTroncon;

	public GUI_Point(int x, int y, int numeroTroncon) {
		super(x, y);
		this.numeroTroncon = numeroTroncon;
	}

	public int getNumeroTroncon() {
		return numeroTroncon;
	}

}
