package view;

import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import model.FeuxSignalisation;
import model.Voiture;

/*
 * Cette classe nous permet d'effectuer la simulation du trafic.
 * En prenant en compte l'etat du trafic.
 * */
public class GUI_Simulation {
	private ArrayList<Voiture> listeVoitures;

	public ArrayList<Voiture> getListeVoitures() {
		return listeVoitures;
	}

	public GUI_Simulation(ArrayList<ArrayList<GUI_Point>> listePositionsParTrajet, int nombreVoiture) {
		genereVoitures(listePositionsParTrajet, nombreVoiture);
	}

	/*
	 * On genere les voitures selon le nombre defini par l'utilisateur, chaque
	 * voiture connait le trajet a suivre
	 */
	public ArrayList<Voiture> genereVoitures(ArrayList<ArrayList<GUI_Point>> listePositionsParTrajet,
			int nombreVoiture) {
		this.listeVoitures = new ArrayList<Voiture>();
		Random randomGenerator = new Random();
		int numTrajet;
		int numLogo;
		BufferedImage img = null;

		for (int i = 0; i < nombreVoiture; i++) {
			// Pour chaque voiture, le trajet est genere de facon aleatoire.
			numTrajet = randomGenerator.nextInt(listePositionsParTrajet.size());

			// Pour chaque voiture, le logo pour la simulation est genere de facon
			// aleatoire.
			numLogo = randomGenerator.nextInt(4) + 1;

			try {
				File f = new File("img/" + numLogo + ".png");
				img = ImageIO.read(f);
			} catch (Exception ex) {
				System.out.println(ex);
			}

			listeVoitures.add(new Voiture(numLogo, listePositionsParTrajet.get(numTrajet).get(0).x,
					listePositionsParTrajet.get(numTrajet).get(0).y, img, listePositionsParTrajet.get(numTrajet)));
		}
		return this.listeVoitures;
	}

	/* Cette methode donne l'index d'un point dans le sprite */
	public int indexDansSprite(ArrayList<JButton> sprite, int x, int y) {
		int indice = -1;
		for (int i = 0; i < sprite.size(); i++) {
			if (sprite.get(i).getLocation().x == x && sprite.get(i).getLocation().y == y) {
				indice = i;
				break;
			}
		}
		return indice;
	}

	/* Cette methode donne l'index d'un point dans le sprite */
	public int indexDansSprite(ArrayList<JButton> sprite, Point p) {
		int indice = -1;
		for (int i = 0; i < sprite.size(); i++) {
			if (sprite.get(i).getLocation().x == p.x && sprite.get(i).getLocation().y == p.y) {
				indice = i;
				break;
			}
		}
		return indice;
	}

	/* Cette methode donne la position suivante d'une voiture pour son trajet. */
	public Point suivantDansTrajet(Voiture voiture) {
		int indice = -1;

		for (int i = 0; i < voiture.getTrajet().size(); i++) {
			if (voiture.getPosition().x == voiture.getTrajet().get(i).x
					&& voiture.getPosition().y == voiture.getTrajet().get(i).y) {
				indice = i + 1; // Point suivant
				break;
			}
		}
		if (indice == voiture.getTrajet().size() || indice == -1) {
			return new Point(-1, -1);
		} else {
			return new Point(voiture.getTrajet().get(indice).x, voiture.getTrajet().get(indice).y);
		}
	}

	/* Cette methode permet de definir si le rond-point est congestionne */
	public boolean rondPointEstCongestionne(ArrayList<JButton> sprite, int capaciteMaxRondPoint) {
		int compteur = 0;
		if (sprite.get(indexDansSprite(sprite, 492, 415)).isVisible()) {
			compteur += 1;
		}
		if (sprite.get(indexDansSprite(sprite, 504, 435)).isVisible()) {
			compteur += 1;
		}
		if (sprite.get(indexDansSprite(sprite, 525, 435)).isVisible()) {
			compteur += 1;
		}
		if (sprite.get(indexDansSprite(sprite, 540, 415)).isVisible()) {
			compteur += 1;
		}
		if (sprite.get(indexDansSprite(sprite, 540, 396)).isVisible()) {
			compteur += 1;
		}
		if (sprite.get(indexDansSprite(sprite, 525, 375)).isVisible()) {
			compteur += 1;
		}
		if (sprite.get(indexDansSprite(sprite, 508, 380)).isVisible()) {
			compteur += 1;
		}
		if (sprite.get(indexDansSprite(sprite, 487, 396)).isVisible()) {
			compteur += 1;
		}

		return compteur == capaciteMaxRondPoint;

	}

	/*
	 * Cette methode permet de definir si un index quelconque est une position du
	 * rond-point
	 */
	public boolean estDansRondPoint(ArrayList<JButton> sprite, int index) {
		return ((indexDansSprite(sprite, 492, 415) == index) || (indexDansSprite(sprite, 504, 435) == index)
				|| (indexDansSprite(sprite, 525, 435) == index) || (indexDansSprite(sprite, 540, 415) == index)
				|| (indexDansSprite(sprite, 540, 396) == index) || (indexDansSprite(sprite, 525, 375) == index)
				|| (indexDansSprite(sprite, 508, 380) == index) || (indexDansSprite(sprite, 487, 396) == index));
	}

	/* Cette methode permet de vider le rond-point s'il est congestionne */
	public void viderRondPoint(JPanel unPanel, ArrayList<JButton> LesSprites, ArrayList<Voiture> listeVoiture) {
		int indexSuivant = -1;
		int indexActuel;

		for (int i = 0; i < listeVoiture.size(); i++) {
			indexSuivant = indexDansSprite(LesSprites, suivantDansTrajet(listeVoiture.get(i)));
			indexActuel = indexDansSprite(LesSprites, listeVoiture.get(i).getPosition().x,
					listeVoiture.get(i).getPosition().y);
			if (estDansRondPoint(LesSprites, indexActuel)) {
				if (!LesSprites.get(indexSuivant).isVisible()) // La position suivante est libre.
				{
					LesSprites.get(indexActuel).setVisible(false);

					BufferedImage img = null;
					try {
						File f = new File("img/" + listeVoiture.get(i).getCouleur() + ".png");
						img = ImageIO.read(f);
					} catch (Exception ex) {
						System.out.println(ex);
					}

					listeVoiture.get(i).setPosition(suivantDansTrajet(listeVoiture.get(i)));
					LesSprites.get(indexSuivant).setIcon(new ImageIcon(img));
					LesSprites.get(indexSuivant).setVisible(true);

				} else {

				}
			}

		}
	}

	/*
	 * Cette methode permet de savoir combien de voitures n'ont pas fini leur
	 * trajet.
	 */
	public int nombreVoituresActives(ArrayList<JButton> LesSprites) {
		int compteur = 0;
		for (int i = 0; i < LesSprites.size(); i++) {
			if (LesSprites.get(i).isVisible()) {
				compteur += 1;
			}
		}

		return compteur;
	}

	/*
	 * Cette methode permet de savoir combien de voiture sont sur le troncon de
	 * sortie de l'autoroute
	 */
	public int nombreVoitureSurTronconSortie() {
		int compteur = 0;

		for (int i = 0; i < listeVoitures.size(); i++) {
			if (listeVoitures.get(i).getPosition().x == 64 && listeVoitures.get(i).getPosition().y == 415) {
				compteur += 1;
				continue;
			}
			if (listeVoitures.get(i).getPosition().x == 114 && listeVoitures.get(i).getPosition().y == 415) {
				compteur += 1;
				continue;
			}
			if (listeVoitures.get(i).getPosition().x == 164 && listeVoitures.get(i).getPosition().y == 415) {
				compteur += 1;
				continue;
			}
			if (listeVoitures.get(i).getPosition().x == 214 && listeVoitures.get(i).getPosition().y == 415) {
				compteur += 1;
				continue;
			}
			if (listeVoitures.get(i).getPosition().x == 264 && listeVoitures.get(i).getPosition().y == 415) {
				compteur += 1;
				continue;
			}
			if (listeVoitures.get(i).getPosition().x == 314 && listeVoitures.get(i).getPosition().y == 415) {
				compteur += 1;
				continue;
			}
			if (listeVoitures.get(i).getPosition().x == 364 && listeVoitures.get(i).getPosition().y == 415) {
				compteur += 1;
				continue;
			}
			if (listeVoitures.get(i).getPosition().x == 414 && listeVoitures.get(i).getPosition().y == 415) {
				compteur += 1;
				continue;
			}
			if (listeVoitures.get(i).getPosition().x == 464 && listeVoitures.get(i).getPosition().y == 415) {
				compteur += 1;
			}
		}

		return compteur;
	}

	public void initialiser(JPanel unPanel, ArrayList<JButton> lesSprites, int couleurFeux, int capaciteMaxRondPoint) {
		int indexSuivant = -1;

		ArrayList<JButton> sprite = new ArrayList<JButton>(lesSprites);

		// Les coordonnees de la position au feu rouge est (464, 415)
		int indexFeuRouge = indexDansSprite(sprite, 464, 415);
		int indexActuel;

		for (int i = 0; i < sprite.size(); i++) {
			unPanel.add(sprite.get(i));
		}

		for (int i = 0; i < listeVoitures.size(); i++) {
			indexSuivant = indexDansSprite(sprite, suivantDansTrajet(listeVoitures.get(i)));
			indexActuel = indexDansSprite(sprite, listeVoitures.get(i).getPosition().x,
					listeVoitures.get(i).getPosition().y);

			if (rondPointEstCongestionne(sprite, capaciteMaxRondPoint)) {
				if (!estDansRondPoint(sprite, indexActuel) && (estDansRondPoint(sprite, indexSuivant))) {
					continue;
				}
			}

			if (couleurFeux == FeuxSignalisation.getCouleurRouge()) {
				if (indexActuel == indexFeuRouge) {
					// On ne fait rien
				} else {
					if (indexSuivant == -1) // Il n'a pas de suivant.
					{
						if (listeVoitures.get(i).getPosition().x == -1 && listeVoitures.get(i).getPosition().y == -1) {

						} else {
							sprite.get(indexDansSprite(sprite, listeVoitures.get(i).getPosition().x,
									listeVoitures.get(i).getPosition().y)).setVisible(false);
							listeVoitures.get(i).setPosition(new Point(-1, -1));
						}
					} else // Il y a une position suivante
					{
						if (!sprite.get(indexSuivant).isVisible()) // La position suivante est libre.
						{
							sprite.get(indexActuel).setVisible(false);

							BufferedImage img = null;
							try {
								File f = new File("img/" + listeVoitures.get(i).getCouleur() + ".png");
								img = ImageIO.read(f);
							} catch (Exception ex) {
								System.out.println(ex);
							}

							listeVoitures.get(i).setPosition(suivantDansTrajet(listeVoitures.get(i)));
							sprite.get(indexSuivant).setIcon(new ImageIcon(img));
							sprite.get(indexSuivant).setVisible(true);

						}
					}
				}
			} else {
				if (indexSuivant == -1) // Il n'a pas de suivant.
				{
					if (listeVoitures.get(i).getPosition().x == -1 && listeVoitures.get(i).getPosition().y == -1) {

					} else {
						sprite.get(indexActuel).setVisible(false);
						listeVoitures.get(i).setPosition(new Point(-1, -1));
					}
				} else // Il y a une position suivante
				{
					if (!sprite.get(indexSuivant).isVisible()) // La position suivante est libre.
					{
						sprite.get(indexActuel).setVisible(false);

						BufferedImage img = null;
						try {
							File f = new File("img/" + listeVoitures.get(i).getCouleur() + ".png");
							img = ImageIO.read(f);
						} catch (Exception ex) {
							System.out.println(ex);
						}

						listeVoitures.get(i).setPosition(suivantDansTrajet(listeVoitures.get(i)));
						sprite.get(indexSuivant).setIcon(new ImageIcon(img));
						sprite.get(indexSuivant).setVisible(true);

					}
				}
			}
		}

	}
}
