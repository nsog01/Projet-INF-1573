package view;

import java.util.ArrayList;

import model.Trajet;
import model.Troncon;

/*Cette permet de definir tous les trajets possibles que puisse prendre une voiture sur notre carte.*/
public class GUI_Trajet {

	private ArrayList<Trajet> listeTrajets;
	private ArrayList<ArrayList<GUI_Point>> listePositionsParTrajet;

	public ArrayList<ArrayList<GUI_Point>> getListePositionsTrajet() {
		return listePositionsParTrajet;
	}

	public ArrayList<Trajet> getListeTrajets() {
		return listeTrajets;
	}

	public GUI_Trajet(ArrayList<Troncon> listeTroncon, ArrayList<ArrayList<GUI_Point>> listePositionsParTroncon) {
		listeTrajets = new ArrayList<Trajet>();
		listePositionsParTrajet = new ArrayList<ArrayList<GUI_Point>>();

		Trajet tr1 = new Trajet();
		tr1.ajouterTroncon(listeTroncon.get(0));
		tr1.ajouterTroncon(listeTroncon.get(1));
		listeTrajets.add(tr1);

		Trajet tr2 = new Trajet();
		tr2.ajouterTroncon(listeTroncon.get(0));
		tr2.ajouterTroncon(listeTroncon.get(2));
		tr2.ajouterTroncon(listeTroncon.get(3));
		tr2.ajouterTroncon(listeTroncon.get(4));
		listeTrajets.add(tr2);

		Trajet tr3 = new Trajet();
		tr3.ajouterTroncon(listeTroncon.get(0));
		tr3.ajouterTroncon(listeTroncon.get(2));
		tr3.ajouterTroncon(listeTroncon.get(3));
		tr3.ajouterTroncon(listeTroncon.get(6));
		tr3.ajouterTroncon(listeTroncon.get(7));
		listeTrajets.add(tr3);

		Trajet tr4 = new Trajet();
		tr4.ajouterTroncon(listeTroncon.get(0));
		tr4.ajouterTroncon(listeTroncon.get(2));
		tr4.ajouterTroncon(listeTroncon.get(3));
		tr4.ajouterTroncon(listeTroncon.get(6));
		tr4.ajouterTroncon(listeTroncon.get(9));
		tr4.ajouterTroncon(listeTroncon.get(10));
		listeTrajets.add(tr4);

		Trajet tr5 = new Trajet();
		tr5.ajouterTroncon(listeTroncon.get(0));
		tr5.ajouterTroncon(listeTroncon.get(2));
		tr5.ajouterTroncon(listeTroncon.get(3));
		tr5.ajouterTroncon(listeTroncon.get(6));
		tr5.ajouterTroncon(listeTroncon.get(9));
		tr5.ajouterTroncon(listeTroncon.get(12));
		tr5.ajouterTroncon(listeTroncon.get(13));
		tr5.ajouterTroncon(listeTroncon.get(1));
		listeTrajets.add(tr5);

		Trajet tr6 = new Trajet();
		tr6.ajouterTroncon(listeTroncon.get(5));
		tr6.ajouterTroncon(listeTroncon.get(6));
		tr6.ajouterTroncon(listeTroncon.get(7));
		listeTrajets.add(tr6);

		Trajet tr7 = new Trajet();
		tr7.ajouterTroncon(listeTroncon.get(5));
		tr7.ajouterTroncon(listeTroncon.get(6));
		tr7.ajouterTroncon(listeTroncon.get(9));
		tr7.ajouterTroncon(listeTroncon.get(10));
		listeTrajets.add(tr7);

		Trajet tr8 = new Trajet();
		tr8.ajouterTroncon(listeTroncon.get(5));
		tr8.ajouterTroncon(listeTroncon.get(6));
		tr8.ajouterTroncon(listeTroncon.get(9));
		tr8.ajouterTroncon(listeTroncon.get(12));
		tr8.ajouterTroncon(listeTroncon.get(13));
		tr8.ajouterTroncon(listeTroncon.get(1));
		listeTrajets.add(tr8);

		Trajet tr9 = new Trajet();
		tr9.ajouterTroncon(listeTroncon.get(5));
		tr9.ajouterTroncon(listeTroncon.get(6));
		tr9.ajouterTroncon(listeTroncon.get(9));
		tr9.ajouterTroncon(listeTroncon.get(12));
		tr9.ajouterTroncon(listeTroncon.get(3));
		tr9.ajouterTroncon(listeTroncon.get(4));
		listeTrajets.add(tr9);

		Trajet tr10 = new Trajet();
		tr10.ajouterTroncon(listeTroncon.get(8));
		tr10.ajouterTroncon(listeTroncon.get(9));
		tr10.ajouterTroncon(listeTroncon.get(10));
		listeTrajets.add(tr10);

		Trajet tr11 = new Trajet();
		tr11.ajouterTroncon(listeTroncon.get(8));
		tr11.ajouterTroncon(listeTroncon.get(9));
		tr11.ajouterTroncon(listeTroncon.get(12));
		tr11.ajouterTroncon(listeTroncon.get(13));
		tr11.ajouterTroncon(listeTroncon.get(1));
		listeTrajets.add(tr11);

		Trajet tr12 = new Trajet();
		tr12.ajouterTroncon(listeTroncon.get(8));
		tr12.ajouterTroncon(listeTroncon.get(9));
		tr12.ajouterTroncon(listeTroncon.get(12));
		tr12.ajouterTroncon(listeTroncon.get(3));
		tr12.ajouterTroncon(listeTroncon.get(4));
		listeTrajets.add(tr12);

		Trajet tr13 = new Trajet();
		tr13.ajouterTroncon(listeTroncon.get(8));
		tr13.ajouterTroncon(listeTroncon.get(9));
		tr13.ajouterTroncon(listeTroncon.get(12));
		tr13.ajouterTroncon(listeTroncon.get(3));
		tr13.ajouterTroncon(listeTroncon.get(6));
		tr13.ajouterTroncon(listeTroncon.get(7));
		listeTrajets.add(tr13);

		Trajet tr14 = new Trajet();
		tr14.ajouterTroncon(listeTroncon.get(11));
		tr14.ajouterTroncon(listeTroncon.get(12));
		tr14.ajouterTroncon(listeTroncon.get(13));
		tr14.ajouterTroncon(listeTroncon.get(1));
		listeTrajets.add(tr14);

		Trajet tr15 = new Trajet();
		tr15.ajouterTroncon(listeTroncon.get(11));
		tr15.ajouterTroncon(listeTroncon.get(12));
		tr15.ajouterTroncon(listeTroncon.get(3));
		tr15.ajouterTroncon(listeTroncon.get(4));
		listeTrajets.add(tr15);

		Trajet tr16 = new Trajet();
		tr16.ajouterTroncon(listeTroncon.get(11));
		tr16.ajouterTroncon(listeTroncon.get(12));
		tr16.ajouterTroncon(listeTroncon.get(3));
		tr16.ajouterTroncon(listeTroncon.get(6));
		tr16.ajouterTroncon(listeTroncon.get(7));
		listeTrajets.add(tr16);

		Trajet tr17 = new Trajet();
		tr17.ajouterTroncon(listeTroncon.get(11));
		tr17.ajouterTroncon(listeTroncon.get(12));
		tr17.ajouterTroncon(listeTroncon.get(3));
		tr17.ajouterTroncon(listeTroncon.get(6));
		tr17.ajouterTroncon(listeTroncon.get(9));
		tr17.ajouterTroncon(listeTroncon.get(10));
		listeTrajets.add(tr17);

		genererPositionsTrajets(listeTroncon, listePositionsParTroncon);
	}

	public void genererPositionsTrajets(ArrayList<Troncon> listeTroncons,
			ArrayList<ArrayList<GUI_Point>> listePositionsParTroncon) {
		ArrayList<GUI_Point> listePositions = null;
		for (int i = 0; i < listeTrajets.size(); i++) {
			listePositions = new ArrayList<GUI_Point>();

			for (int j = 0; j < listeTrajets.get(i).getListeTroncons().size(); j++) {
				for (int k = 0; k < listeTroncons.size(); k++) {
					if (listeTrajets.get(i).getListeTroncons().get(j).getNumeroTroncon() == listeTroncons.get(k)
							.getNumeroTroncon()) {

						for (int n = 0; n < listePositionsParTroncon.get(k).size(); n++) {
							listePositions.add(listePositionsParTroncon.get(k).get(n));
						}

					}
				}
			}
			listePositionsParTrajet.add(listePositions);

		}
	}

}
