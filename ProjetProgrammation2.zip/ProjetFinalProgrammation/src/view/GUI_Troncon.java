package view;

import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;

import model.Troncon;

/*Cette classe permet de gerer les differents troncons. Nous utiliserons plutard la notion de 
 * troncon pour definir la notion de TRAJET, un TRAJET etant une suite de troncons. Et un troncon 
 * definit l'ensemble des positions (repere dans l'espace) que peut occuper une voiture sur ledit troncon.*/
public class GUI_Troncon {

	private ArrayList<Troncon> listeTroncons;
	private ArrayList<ArrayList<GUI_Point>> listePositionsParTroncon;
	private ArrayList<JButton> sprite;

	public ArrayList<ArrayList<GUI_Point>> getListePositionsParTroncon() {
		return listePositionsParTroncon;
	}

	public ArrayList<Troncon> getListeTroncon() {
		return listeTroncons;
	}

	public ArrayList<JButton> getSprite() {
		return sprite;
	}

	public GUI_Troncon(JPanel unPanel) {
		definirTroncons();
		definirPositions();
		genererSprite();
	}

	public void definirTroncons() {
		this.listeTroncons = new ArrayList<Troncon>();
		this.listePositionsParTroncon = new ArrayList<ArrayList<GUI_Point>>();
		listeTroncons.add(new Troncon(1, new GUI_Point(33, 720, 1), new GUI_Point(33, 428, 1), 7));
		listeTroncons.add(new Troncon(2, new GUI_Point(33, 394, 2), new GUI_Point(33, 6, 2), 9));
		listeTroncons.add(new Troncon(3, new GUI_Point(64, 415, 3), new GUI_Point(475, 415, 3), 9));
		listeTroncons.add(new Troncon(4, new GUI_Point(492, 415, 4), new GUI_Point(504, 435, 4), 2));

		listeTroncons.add(new Troncon(5, new GUI_Point(505, 460, 5), new GUI_Point(505, 743, 5), 6));
		listeTroncons.add(new Troncon(6, new GUI_Point(525, 757, 6), new GUI_Point(525, 458, 6), 7));
		listeTroncons.add(new Troncon(7, new GUI_Point(525, 435, 7), new GUI_Point(540, 415, 7), 2));
		listeTroncons.add(new Troncon(8, new GUI_Point(567, 415, 8), new GUI_Point(1089, 415, 8), 11));
		listeTroncons.add(new Troncon(9, new GUI_Point(1062, 396, 9), new GUI_Point(567, 396, 9), 11));

		listeTroncons.add(new Troncon(10, new GUI_Point(540, 396, 10), new GUI_Point(525, 375, 10), 2));
		listeTroncons.add(new Troncon(11, new GUI_Point(525, 370, 11), new GUI_Point(525, 6, 11), 10));
		listeTroncons.add(new Troncon(12, new GUI_Point(505, 6, 12), new GUI_Point(505, 371, 12), 8));
		listeTroncons.add(new Troncon(13, new GUI_Point(508, 380, 13), new GUI_Point(487, 396, 13), 2));
		listeTroncons.add(new Troncon(14, new GUI_Point(464, 396, 14), new GUI_Point(56, 396, 14), 9));
	}

	public void definirPositions() {
		/* Distance entre 2 positions */
		int pas = 50;
		ArrayList<GUI_Point> liste = new ArrayList<GUI_Point>();

		for (int k = 0; k < listeTroncons.size(); k++) {

			if (listeTroncons.get(k).getNumeroTroncon() == 1) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
							listeTroncons.get(k).getDebutTroncon().y - (i * pas), 1));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 2) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
							listeTroncons.get(k).getDebutTroncon().y - (i * pas), 2));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 3) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x + (i * pas),
							listeTroncons.get(k).getDebutTroncon().y, 3));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 4) {
				liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
						listeTroncons.get(k).getDebutTroncon().y, 4));
				liste.add(new GUI_Point(listeTroncons.get(k).getFinTroncon().x, listeTroncons.get(k).getFinTroncon().y,
						4));
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 5) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
							listeTroncons.get(k).getDebutTroncon().y + (i * pas), 5));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 6) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
							listeTroncons.get(k).getDebutTroncon().y - (i * pas), 6));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}
			if (listeTroncons.get(k).getNumeroTroncon() == 7) {
				liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
						listeTroncons.get(k).getDebutTroncon().y, 7));
				liste.add(new GUI_Point(listeTroncons.get(k).getFinTroncon().x, listeTroncons.get(k).getFinTroncon().y,
						7));
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 8) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x + (i * pas),
							listeTroncons.get(k).getDebutTroncon().y, 8));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 9) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x - (i * pas),
							listeTroncons.get(k).getDebutTroncon().y, 9));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 10) {
				liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
						listeTroncons.get(k).getDebutTroncon().y, 10));
				liste.add(new GUI_Point(listeTroncons.get(k).getFinTroncon().x, listeTroncons.get(k).getFinTroncon().y,
						10));
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 11) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
							listeTroncons.get(k).getDebutTroncon().y - (i * pas), 11));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}

			if (listeTroncons.get(k).getNumeroTroncon() == 12) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
							listeTroncons.get(k).getDebutTroncon().y + (i * pas), 12));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}
			if (listeTroncons.get(k).getNumeroTroncon() == 13) {
				liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x,
						listeTroncons.get(k).getDebutTroncon().y, 13));
				liste.add(new GUI_Point(listeTroncons.get(k).getFinTroncon().x, listeTroncons.get(k).getFinTroncon().y,
						13));
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}
			if (listeTroncons.get(k).getNumeroTroncon() == 14) {
				for (int i = 0; i < listeTroncons.get(k).getCapaciteMax(); i++) {
					liste.add(new GUI_Point(listeTroncons.get(k).getDebutTroncon().x - (i * pas),
							listeTroncons.get(k).getDebutTroncon().y, 14));
				}
				listePositionsParTroncon.add(new ArrayList<GUI_Point>(liste));
				liste.clear();
			}
		}

	}

	public void genererSprite() {
		this.sprite = new ArrayList<JButton>();

		for (int k = 0; k < listePositionsParTroncon.size(); k++) {
			for (int i = 0; i < listePositionsParTroncon.get(k).size(); i++) {
				JButton j = new JButton();

				j.setLocation(listePositionsParTroncon.get(k).get(i).x, listePositionsParTroncon.get(k).get(i).y);
				j.setSize(20, 20);
				j.setVisible(false);
				j.setOpaque(false);
				j.setContentAreaFilled(false);
				j.setBorderPainted(false);
				sprite.add(j);
			}
		}
	}

	public void reinitialiseSprite() {
		for (int k = 0; k < sprite.size(); k++) {
			sprite.get(k).setVisible(false);
		}
	}
}
